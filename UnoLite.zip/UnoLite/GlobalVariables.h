#ifndef GLOBALVARIABLES_H
#define GLOBALVARIABLES_H
#include <QString>

//Var to save player name
static QString PlayerName = nullptr;
static QString PlayerNameFile = "PlayerNameFile.txt";

#endif // GLOBALVARIABLES_H
